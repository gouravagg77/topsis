#Topsis Package
A Python package to implement topsis on a given dataset.
##Usage
Following query on terminal will provide you the best and worst decisions for the dataset.
```
python topsis.py dataset_sample.csv 1,1,1,1 0,1,1,0
```